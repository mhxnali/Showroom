-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2025 at 09:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `showroom`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `booking_type` varchar(255) NOT NULL,
  `pref_time` varchar(255) NOT NULL,
  `adv_pay` varchar(255) NOT NULL,
  `pay_mode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `name`, `contact`, `booking_type`, `pref_time`, `adv_pay`, `pay_mode`) VALUES
(1, 'Faizan Khan', '0355-1212301', 'Car Services/Oil,Filter Change/General Tuning ', '10-AUG-2025', '10,000PKR', 'Card'),
(2, 'Asim Munir', '0333-1115500', 'Vehicle Booked', '10-SEP-2025', '35,000,000', 'Bank Pay Order'),
(3, 'Fahad Sheikh', '0312-9361022', 'Auto/Spare-Part/1:Engine,4:Suspension,2:Carbon-Fibre Side-Skirts,1:Front Body-Kit', '12-AUG-2025', '110,000', 'Cash'),
(7, 'Hamza', '0312-4351711', 'Wheel Alignment', '2025-08-12T09:44', '50,000,00', 'Cash'),
(8, 'Hamza', '0312-4351711', 'Wheel Alignment', '2025-08-12T09:44', '50,000,00', 'Cash'),
(9, 'Ashar Imran', '0300-6664014', 'Car Detailing', '2025-08-28T16:20', '60,000 PKR', 'Card'),
(10, 'Arsalan Khan', '0306-4600289', 'Brake Service', '2025-08-22T10:33', '60000', 'Cash'),
(11, 'Abrar Ahmed', '0305-1253366', 'Oil Change', '2025-09-10T09:16', '25000 ', 'Card');

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `model` varchar(50) DEFAULT NULL,
  `engine_cc` varchar(11) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `added_on` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `name`, `model`, `engine_cc`, `price`, `image`, `added_on`) VALUES
(1, 'Toyota Prius', '2019', '1800cc', '7500000 ', 'El Toyota Prius.jpeg', '2025-08-04 10:20:20'),
(2, 'Honda Civic', '2025', '1500cc', '8500000 ', 'Honda Civic.jpeg', '2025-08-04 10:20:20'),
(3, 'Toyota Supra', '2020', '3500cc', '5500000', 'Toyota Supra.jpeg', '2025-08-04 10:20:20'),
(6, 'Toyota Land Cruiser (LC-200) ', '2022', 'v8 3500cc', '50000000 ', 'Landing page for Toyota Land Cruiser 200 - Ksenia Anso.jpeg', '2025-08-06 10:58:07'),
(7, 'Honda Civic (Rebirth)', '2016', '1800cc', '3600000', 'download.jpeg', '2025-08-06 11:04:24'),
(8, 'Toyota Crown Rs-Advance', '2019', '3500cc', '20000000', 'download (1).jpeg', '2025-08-06 11:11:18'),
(9, 'BMW-i7', '2020', 'Electric', '100000000', 'BMW i7 CGi Photoshoot - Damian Bilinski.jpeg', '2025-08-23 04:33:32'),
(10, 'Haval-H6', '2025', '2000cc', '12000000', '2024 Haval H6 - Stunning HD Photos, Videos, Specs, Features & Price - DailyRevs.jpeg', '2025-08-23 04:38:34'),
(11, 'Range Rover', '2025', '3500cc', '140000000', 'download (2).jpeg', '2025-08-23 04:43:27'),
(12, 'Hyundai Sonata N-line', '2025', '2500cc', '17000000', 'Hyundai Sonata N Line 2023.jpeg', '2025-08-23 04:46:26'),
(13, 'Mercedes E-Class E400', '2023', 'v8 Turbo', '50000000', '2025 Mercedes-Benz E-Class_ The Future of Luxury, Redefined!.jpeg', '2025-08-23 04:49:02'),
(14, 'Mercedes S-Class s680 Maybach ', '2025', 'v8', '150000000', 'S 680 Maybach.jpeg', '2025-08-23 04:53:00'),
(15, 'BMW-M4 Competition ', '2023', 'v8 Turbo', '60000000', 'BMW M4 Competition.jpeg', '2025-08-23 04:56:39'),
(17, 'Toyota Camry', '2025', '2800cc', '20000000', '2025 Toyota Camry Hybrid_ Enhanced Performance, Safety, and Efficiency - fast car 10.jpeg', '2025-08-23 05:02:00'),
(18, 'Honda Accord Turbo Sport', '2023', '1500cc', '2.3000000', 'Honda Accord Turbo Sport - CH version 2023.jpeg', '2025-08-23 05:12:57'),
(19, 'Rolls-Royce Phantom', '2023', '6.5L v12 ', '220000000', '$444_000.jpeg', '2025-08-23 05:20:00'),
(21, 'Honda City ', '2022', '1300cc', '4300000', 'Honda City.jpeg', '2025-08-23 05:24:11'),
(22, 'Suzuki Swift', '2022', '1299cc', '4200000', 'What is the Average Price of a Used Maruti Suzuki Swift_ - WinkRecipe.jpeg', '2025-08-23 05:25:25'),
(23, 'Suzuki Alto', '2023', '660cc', '2600000', 'creative car post.jpeg', '2025-08-23 05:35:49'),
(24, 'Toyota Corolla Cross Hybrid 1.8 X', '2024', '1800cc', '9800000', '2025 Toyota Corolla Cross _ Toyota_com.jpeg', '2025-08-23 05:39:32'),
(26, 'Toyota Yaris (Hatchback)', '2023', '1500cc', '4500000', 'download (4).jpeg', '2025-08-23 05:42:51'),
(27, 'Tesla Model-S', '2020', 'Electric', '22000000', 'Tesla model S plaid.jpeg', '2025-08-23 05:45:03'),
(32, 'Hyundai Elantra Hybrid', '2025', '2000cc', '9800000', '2025 Hyundai Elantra Hybrid Review_ Affordable Gas Whisperer.jpeg', '2025-08-23 05:47:47'),
(33, 'Lexus LX600', '2025', '3500cc', '90000000', 'Lexus LX600.jpeg', '2025-08-23 05:52:08'),
(34, 'Land Cruiser LC300', '2024', 'V6 3500cc', '70000000', 'download (5).jpeg', '2025-08-23 05:55:12'),
(35, 'BMW-i8 Roadster', '2018', 'Electric', '1.5000000', 'BMW i8 Roadster.jpeg', '2025-08-23 06:04:46'),
(36, 'Porsche Tycan', '2024', '3500cc', '6000000', 'Porsche.jpeg', '2025-08-23 06:22:38'),
(37, 'Audi A6', '2020', '2800cc', '20000000', 'download (7).jpeg', '2025-08-23 06:26:16');

-- --------------------------------------------------------

--
-- Table structure for table `cars_inventory`
--

CREATE TABLE `cars_inventory` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `engine_size` varchar(50) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `model_year` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cars_inventory`
--

INSERT INTO `cars_inventory` (`id`, `name`, `engine_size`, `brand`, `model_year`, `price`, `quantity`) VALUES
(1, ' Civic/2021', '2000cc', 'Honda', 2021, 6300000, 5),
(2, 'Corolla/2022', '1500cc', 'Toyota', 2022, 6100000, 2),
(3, 'Land Cruiser/2017', '3500cc', 'Toyota', 2017, 17500000, 4),
(4, 'Honda City', '1300cc', 'Honda', 2021, 4500000, 12);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `email`, `contact`, `address`) VALUES
(1, 'Sami', 'samikhan24@gmail.com', '0312-4351711', 'Wapda Town Phase1 Multan Pakistan'),
(2, 'Babar Azam', 'booby56@gmail.com', '03213422011', 'Gulberg-Lahore/Pakistan'),
(3, 'Zain Sheikh', 'zain_shk98@gmail.com', '111-10101010', 'DHA Multan'),
(4, 'Muhammad Javed', 'M.Jayyd@gmail.com', '0306-4600289', 'Buch-Villas Multan/Pakistan'),
(5, 'M.Hamza Bhatti', 'hbhatti10@gmail.com', '0312-5342911', 'Buch-Villas Multan/Pakistan'),
(6, 'Shahid Iqbal', 'Shahidiiqbal021@gmail.com', '0313-7734022', 'Askari Colony Multan');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `invoice_no` varchar(50) DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `bill_to` varchar(255) DEFAULT NULL,
  `ship_to` varchar(255) DEFAULT NULL,
  `payment_terms` varchar(255) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `po_number` varchar(50) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `tax` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `amount_paid` decimal(10,2) DEFAULT NULL,
  `balance_due` decimal(10,2) DEFAULT NULL,
  `date` date NOT NULL,
  `name` varchar(255) NOT NULL,
  `types` varchar(100) NOT NULL,
  `product` varchar(255) DEFAULT NULL,
  `pay_type` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `items` text DEFAULT NULL,
  `from_who` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `terms` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `invoice_no`, `invoice_date`, `bill_to`, `ship_to`, `payment_terms`, `due_date`, `po_number`, `subtotal`, `tax`, `total`, `amount_paid`, `balance_due`, `date`, `name`, `types`, `product`, `pay_type`, `price`, `items`, `from_who`, `notes`, `terms`) VALUES
(1, 'INV-1755082056', '2025-08-13', 'kashif', 'kashif', '', '0000-00-00', '', 36.00, 0.00, 36.00, 36.00, 0.00, '2025-08-13', 'kashif', 'Car Purchase', 'Honda Civic (Rebirth)', 'Card', 36000000.00, '[{\"item\":\"Honda Civic (Rebirth)\",\"model\":\"2016\",\"engine_cc\":\"1800\",\"rate\":\"36,00,000 PKR\",\"quantity\":1,\"amount\":\"36,00,000 PKR\"}]', '', '', ''),
(2, 'INV-1755581277', '2025-08-19', 'Fahad Sheikh', 'Fahad Sheikh', '', '0000-00-00', '', 7500000.00, 0.00, NULL, 7500000.00, 0.00, '2025-08-19', 'Fahad Sheikh', 'Car Purchase', 'Toyota Prius', 'Cash', 7500000.00, '[{\"item\":\"Toyota Prius\",\"model\":\"2019\",\"engine_cc\":\"1800\",\"price\":\"7500000\",\"quantity\":1,\"amount\":\"7500000\"}]', '', '', ''),
(3, 'INV-1755581501', '2025-08-19', 'Saad Khan', 'Saad Khan', '', '0000-00-00', '', 8.00, 0.00, NULL, 8.00, 0.00, '2025-08-19', 'Saad Khan', 'Car Purchase', 'Honda Civic', 'Cash', 80000000.00, '[{\"item\":\"Honda Civic\",\"model\":\"2025\",\"engine_cc\":\"1500\",\"price\":\"8,500,000 PKR\",\"quantity\":1,\"amount\":\"8,500,000 PKR\"}]', '', '', ''),
(4, 'INV-1755582892', '2025-08-19', 'Khalid Bshir', 'Mall Road Lahore', '', '0000-00-00', '', 25000.00, 0.00, 25000.00, 25000.00, 0.00, '2025-08-19', 'Khalid Bshir', 'Spare Part', 'Transmission', 'Cash', 25000.00, '[{\"id\":\"Mall Road Lahore\",\"item\":\"Transmission\",\"description\":\"Auto Parts\",\"rate\":\"25000\",\"quantity\":1,\"amount\":\"25000\"}]', '', '', ''),
(5, 'INV-1755587476', '2025-08-19', 'Zahid Khan', 'Zahid Khan', '', '0000-00-00', '', 3600000.00, 0.00, NULL, 3600000.00, 0.00, '2025-08-19', 'Zahid Khan', 'Car Purchase', 'Honda Civic (Rebirth)', 'Cash', 3600000.00, '[{\"item\":\"Honda Civic (Rebirth)\",\"model\":\"2016\",\"engine_cc\":\"1800\",\"price\":\"3600000 PKR\",\"quantity\":1,\"amount\":\"3600000 PKR\"}]', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_items`
--

CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `car_id` int(11) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_name`, `car_id`, `order_date`, `status`) VALUES
(1, 'Ali Khan', 1, '2025-08-01', 'Pending'),
(2, 'Sara Ahmed', 2, '2025-08-02', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `types` varchar(255) NOT NULL,
  `product` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `pay_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `date`, `name`, `types`, `product`, `price`, `pay_type`) VALUES
(1, '04-SEP-2025', 'Asad Sohail', 'Car/spare part', 'Honda Civic Rare Lights', '150,000 PKR', 'Cash/Card/Online Banking '),
(2, '19-Dec-2025', 'Ahsen Khan', 'Car/spare part', 'Toyota Vitz Engine', '102,000 PKR', 'Cash/Card/Online Banking'),
(3, '28-08-2025', 'Arishma Sheikh', 'Car/spare part', 'Toyota Prius Body Kits ', '65,000 PKR', 'Card'),
(4, '10-7-2025', 'Hudair Bin Saeed', 'Car Service', 'Oil Change Filters Change General Tuning Throttle Cleaning', '26,000 PKR', 'Online Banking'),
(5, '10-09-2025', 'Ali Hassan Hiraj', 'Car Booking', 'Toyota Land Cruiser (LC-300) 2024', '6,80,00,000 PKR', 'Bank Pay Order'),
(6, '11-11-2025', 'Hamza Javed', 'Car Delivery', 'Toyota Corolla Altis Grande 1.8X (Black Interior) 2025', '7,500,000 PKR', 'Bank Money Pay Order'),
(13, '2025-08-13', 'Fahad Sheikh', 'Spare Part', 'Brake Pads', '25,000 PKR', 'Cash'),
(14, '2025-08-13', 'Fahad Sheikh', 'Spare Part', 'Brake Pads', '25,000 PKR', 'Cash'),
(15, '2025-08-13', 'usman', 'Spare Part', 'Brake Pads', '25,000 PKR', 'Cash');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `category`, `description`, `price`, `image`, `created_at`) VALUES
(11, 'Oil Change', 'Maintenance', 'Complete oil change with high-quality oil & filter', 2500.00, 'oil_change.jpeg', '2025-08-12 06:28:07'),
(12, 'Tire Replacement', 'Maintenance', 'Replace old or damaged tires with new ones', 8000.00, 'tire_replacement.jpeg', '2025-08-12 06:28:07'),
(13, 'Car Wash', 'Cleaning', 'Full exterior and interior car wash', 1500.00, 'car_wash.jpeg', '2025-08-12 06:28:07'),
(14, 'Battery Change', 'Electrical', 'Replace old battery with a new one', 9000.00, 'battery_change.jpeg', '2025-08-12 06:28:07'),
(15, 'Brake Service', 'Safety', 'Brake pad replacement and brake fluid check', 6000.00, 'brake_service.jpeg', '2025-08-12 06:28:07'),
(16, 'Engine Tune-up', 'Maintenance', 'Full engine performance tune-up', 12000.00, 'engine_tuneup.jpeg', '2025-08-12 06:28:07'),
(17, 'AC Repair', 'Cooling', 'Air conditioning system repair and gas refill', 7000.00, 'ac_repair.jpeg', '2025-08-12 06:28:07'),
(18, 'Custom Paint Job', 'Body Work', 'Custom color paint for your vehicle', 25000.00, 'custom_paint.jpeg', '2025-08-12 06:28:07'),
(19, 'Wheel Alignment', 'Maintenance', 'Precision wheel alignment service', 3000.00, 'wheel_alignment.jpeg', '2025-08-12 06:28:07'),
(20, 'Car Detailing', 'Cleaning', 'Full detailing including waxing and polishing', 5000.00, 'car_detailing.jpeg', '2025-08-12 06:28:07'),
(21, 'Engine Timing Belt ', 'Mechanical', 'Belt Replacement', 4000.00, '1755931625_d57f5b382d.jpeg', '2025-08-23 06:37:15'),
(22, 'Drivetrain Services', 'All Kind', 'Car Manufacturing', 50000.00, '68a965d1349dd.jpeg', '2025-08-23 06:55:13'),
(23, 'Engine Repair', 'Mechanical', 'Engine Repair', 50000.00, '68a96c1ea505d.jpeg', '2025-08-23 07:22:06'),
(24, 'Cooling System Service (radiator, hoses, thermostat)', 'Mechanical', 'Cooling System Service (radiator, hoses, thermostat)', 20000.00, '68a96e291d494.jpeg', '2025-08-23 07:30:49'),
(25, 'Electric & Hybrid Vehicle Service', 'Mechanical', 'Electric & Hybrid Vehicle Service', 100000.00, '68a96ec6a970b.jpeg', '2025-08-23 07:33:26'),
(26, 'Steering System Inspection & Repair', 'Interior', 'Steering System Inspection & Repair', 50000.00, '68a96f8a9e345.jpeg', '2025-08-23 07:36:42'),
(27, 'Tire Pressure Monitoring System (TPMS) Service', 'Exterior', 'Tire Pressure Monitoring System (TPMS) Service', 30000.00, '68a970052f8b8.jpeg', '2025-08-23 07:38:45'),
(28, 'Power Steering Fluid Flush', 'Exterior', 'Power Steering Fluid Flush', 15000.00, '68a9706be5982.jpeg', '2025-08-23 07:40:27'),
(29, 'Tire Rotation Tire Balancing Tire Repair Tire Replacement Wheel Inspection', 'Exterior', 'Tire Rotation\r\nTire Balancing\r\nTire Repair\r\nTire Replacement\r\nWheel Inspection', 10000.00, '68a970f22b31c.jpeg', '2025-08-23 07:42:42'),
(30, 'Battery Inspection and Testing', 'mechanical', 'Battery Inspection and Testing', 10000.00, '68a97147ac6ae.jpeg', '2025-08-23 07:44:07');

-- --------------------------------------------------------

--
-- Table structure for table `spare_parts`
--

CREATE TABLE `spare_parts` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `price` varchar(11) DEFAULT NULL,
  `stock` varchar(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `spare_parts`
--

INSERT INTO `spare_parts` (`id`, `name`, `category`, `price`, `stock`, `image`) VALUES
(1, 'Transmission', 'Mechanical', '500000', '43', 'BMW X5.jpeg'),
(2, 'Tyres', 'Exterior', '1000000', '50', 'Car Wheel Icon - Service Tires PNG Transparent With Clear Background ID 201298 _ TopPNG.jpeg'),
(4, 'Bonnet', 'Exterior', '9000000', '65', 'Seibon Carbon Fibre Bonnet - Cw Style - Fits Subaru Impreza Wrx Sti 08-14.jpeg'),
(6, 'Suspension', 'Exterior', '300000 ', '33', 'Find Suspension with ABE for your Car - Ironman 4x4.jpeg'),
(7, 'Fuel Pump', 'Interior', '110000', '55', 'Electric Fuel Pump Module Assembly With Sending Unit Compatible For Infiniti.jpeg'),
(10, 'Brake Pads', 'Mechanical', '1250000', '50', 'Brake Replacement & Upgrade Options - Fix My Car (2).jpeg'),
(11, 'Brake Fluid', 'mechanical', '2000000', '100', 'Penrite Dot 5_1 Brake Fluid 500ML.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `name`, `email`, `password`, `role`) VALUES
(1, 'iHamza_fn', 'Hamza Javed Bhatti', 'hbhatti4123@gmail.com', 'HAVAL205', 'CFO-Askari Petroleum Service'),
(2, 'AFK_manaan', 'Abdul Manan', 'Manaan.abd20@gmail.com', 'Evee_0101', 'CEO-Sharafat Rice Mill and Traders Multan'),
(3, 'no_scope.cod', 'Waleed Mahmood ', 'waleed29wmb@gmail.com', 'pakistan47', 'Doctor'),
(4, 'Blaze_ak', 'Ahsen Khan', 'khanahsen19@gmail.com', 'ahsenK010', 'Entrepreneur'),
(5, 'void_zaidi20', 'Atif Zaidi', 'syed_zaidi27@gmail.com', 'ATIF123', ' Advocate'),
(6, 'Bot-Usman', 'Usman Malik', 'usman33_malik@gmail.com', 'gigs_333666', 'Founder-CEO-CardiBox Logistics');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cars_inventory`
--
ALTER TABLE `cars_inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `spare_parts`
--
ALTER TABLE `spare_parts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `cars_inventory`
--
ALTER TABLE `cars_inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `invoice_items`
--
ALTER TABLE `invoice_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `spare_parts`
--
ALTER TABLE `spare_parts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD CONSTRAINT `invoice_items_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
